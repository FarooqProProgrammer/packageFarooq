class Acha:
    def __int__(self):
        print("constructor")

    def achaFunc(number):
        print("This is a function")
        return number