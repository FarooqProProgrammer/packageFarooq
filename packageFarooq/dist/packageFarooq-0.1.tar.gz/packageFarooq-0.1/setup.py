from setuptools import setup

setup(name="packageFarooq"
      ,version="0.1",
      description="This is Farooq package",
      long_description="This is a very very Long Description",
      author="Farooq",
      packages=['packageFarooq'],
      install_requires=[]
      )